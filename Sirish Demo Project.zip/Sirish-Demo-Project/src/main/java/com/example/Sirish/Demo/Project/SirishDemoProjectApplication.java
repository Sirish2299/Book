package com.example.Sirish.Demo.Project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SirishDemoProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SirishDemoProjectApplication.class, args);
	}

}
